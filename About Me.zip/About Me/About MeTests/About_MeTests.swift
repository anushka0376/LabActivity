//
//  About_MeTests.swift
//  About MeTests
//
//  Created by Anushka Bhatnagar on 30/07/25.
//

import Testing
@testable import About_Me

struct About_MeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
