//
//  Apple_PieTests.swift
//  Apple PieTests
//
//  Created by Anushka Bhatnagar on 21/07/25.
//

import Testing
@testable import Apple_Pie

struct Apple_PieTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
